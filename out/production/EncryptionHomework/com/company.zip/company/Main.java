package com.company;

public class Main {

    public static void main(String[] args) {

        String line = null;
        FileInput inFile = new FileInput("readthis.txt");
        inFile.fileRead();
        while ((line = inFile.fileReadLine()) != null) {
            System.out.println(line);
        }
        inFile.fileClose();
    }
}
